if __name__ == '__main__':
    print('Tipos primitivos em Python')

    # Nome - String (str)
    print('Hércules', type('Hércules'))

    # Idade - Inteiro (int)
    print(35, type(35))

    # Altura - Ponto flutuante (float)
    print(1.7, type(1.7))

    # Pode votar - Booleano (bool)
    print(35 > 18, type(35 > 18))

    # Casting de tipo
    print('Número 10:', int('10'), type(int('10')))
    print('String 10:', str(10), type(str(10)))
