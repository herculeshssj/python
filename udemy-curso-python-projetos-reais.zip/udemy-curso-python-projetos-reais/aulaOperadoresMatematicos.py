if __name__ == '__main__':
    print('Operadores matemáticos')

    print('Soma: 1 + 1 =', 1 + 1)
    print('Subtração: 2 - 1 =', 2 - 1)
    print('Multiplicação: 2 * 2 =', 2 * 2)
    print('Divisão: 5 / 2 =', 5 / 2)

    # Obs: quando a divisão envolve números reais, o resultado será um número real
    print('Divisão inteira: 5 // 2 =', 5 // 2)

    print('Exponenciação: 10 ** 2 =', 10 ** 2)
    print('Módulo (resto da divisão): 5 % 2 =', 5 % 2)

    print('Casos especiais')
    print('Duplicação de strings: letra "A" repetida 10 vezes', 'A' * 10)
    print('Concatenação de strings: A + B =', 'A' + 'B')
