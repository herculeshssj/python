"""
Sempre que for criado um pacote em Python, é necessário criar o arquivo __init__.py para informar ao interpretador
que o diretório atual trata-se de um pacote.
"""