'''
Programa Calculadora

Obs: o programa foi deixado incompleto de propósito. O desafio é quem baixar este repositório conseguir implementar
este programa de calculadora. Boa sorte. ;)
'''

if __name__ == '__main__':
    print('Programa Calculadora')
    print()
    print('Instruções: informe o primeiro valor, o segundo valor e a operação desejada (+, -, *, /)')
    print()

    if True:
        pass
    else:
        pass

    if True:
        ...
    else:
        print('Em breve eu continuo...')
