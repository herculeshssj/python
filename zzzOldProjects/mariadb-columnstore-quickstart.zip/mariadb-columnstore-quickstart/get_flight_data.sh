#!/bin/bash
#Downloading data from MariaDB Sample Data S3 bucket
wget -O data/flights.csv https://sample-columnstore-data.s3.us-west-2.amazonaws.com/flights.csv
