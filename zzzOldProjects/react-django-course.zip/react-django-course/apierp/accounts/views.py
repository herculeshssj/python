from django.shortcuts import render

# Create your views here.
# No tutorial, o instrutor excluiu este arquivo. Caso eu tenha problemas no projeto, 
# posteriormente eu excluirei este arquivo.