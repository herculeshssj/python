export type ApiError = {
    detail: string;
    code?: string;
}