# Popula o arquivo 'palavras.txt' para ser usado pelo programa 'forca.py'

arquivo = open('palavras.txt', 'w')
arquivo.write('banana\n')
arquivo.write('melancia\n')
arquivo.write('morango\n')
arquivo.write('manga\n')
arquivo.close()
